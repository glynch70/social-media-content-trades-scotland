'use client';

import { motion } from 'framer-motion';
import { CheckCircle2 } from 'lucide-react';

const audience = [
  "Builders and contractors taking on bigger jobs",
  "Trades relying too much on word of mouth",
  "Businesses that know they should be posting but don’t",
  "Owners who don’t have time to create content"
];

export default function WhoItsFor() {
  return (
    <section className="py-24 bg-neutral-900">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-5xl font-black mb-8 tracking-tight">
              Built for <span className="text-brand-yellow">Trades Who Want to Grow</span>
            </h2>
            <p className="text-xl text-white/70 mb-10 leading-relaxed">
              We work with ambitious businesses that understand the power of video but don't have the internal resources to execute it consistently.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="space-y-6"
          >
            {audience.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex items-start gap-4 p-6 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 transition-colors duration-300"
              >
                <CheckCircle2 className="text-brand-yellow shrink-0" size={24} />
                <span className="text-lg font-bold text-white/90">{item}</span>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
