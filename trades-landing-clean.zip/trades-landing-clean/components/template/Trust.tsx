'use client';

import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

export default function Trust() {
  return (
    <section className="py-24 bg-neutral-950">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <div className="flex justify-center gap-1 mb-6">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="text-brand-yellow fill-brand-yellow" size={20} />
            ))}
          </div>
          <h2 className="text-3xl md:text-5xl font-black mb-6 tracking-tight">
            Trusted by <span className="text-brand-yellow">Local Businesses Across Scotland</span>
          </h2>
        </div>
 
        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              title: "20+ Years Experience",
              description: "Deep industry knowledge from decades of working with high-growth businesses."
            },
            {
              title: "Built for Trades",
              description: "Specifically designed for trades and service businesses who need real results."
            },
            {
              title: "Reliable & Simple",
              description: "Straightforward, no-hassle service that lets you focus on your jobs."
            }
          ].map((point, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="p-10 bg-white/5 border border-white/10 rounded-3xl text-center"
            >
              <h3 className="text-2xl font-bold text-white mb-4">{point.title}</h3>
              <p className="text-lg text-white/50 leading-relaxed">
                {point.description}
              </p>
            </motion.div>
          ))}
        </div>
        
        <div className="mt-20 flex flex-wrap justify-center gap-12 opacity-30 grayscale hover:grayscale-0 transition-all duration-500">
            {/* Logos could go here */}
            <div className="text-2xl font-black tracking-tighter">PARTNER LOGO</div>
            <div className="text-2xl font-black tracking-tighter">PARTNER LOGO</div>
            <div className="text-2xl font-black tracking-tighter">PARTNER LOGO</div>
            <div className="text-2xl font-black tracking-tighter">PARTNER LOGO</div>
        </div>
      </div>
    </section>
  );
}
