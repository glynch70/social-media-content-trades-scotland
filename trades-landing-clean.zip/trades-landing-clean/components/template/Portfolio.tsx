'use client';

import { motion } from 'framer-motion';
import { Play } from 'lucide-react';
import Image from 'next/image';

const projects = [
  {
    title: "Builder – Custom Shed Project",
    category: " Simply Sheds Scotland",
    youtubeId: "R2j9yS5-K8o",
    image: "https://img.youtube.com/vi/R2j9yS5-K8o/maxresdefault.jpg"
  },
  {
    title: "Refurbishment – Before & After Project",
    category: "Clarets St Andrews",
    youtubeId: "rD0S_7MvE-M",
    image: "https://img.youtube.com/vi/rD0S_7MvE-M/maxresdefault.jpg"
  },
  {
    title: "Contractor – Project Walkthrough",
    category: "Seafood Restaurant",
    youtubeId: "q5e9X9-D9kM",
    image: "https://img.youtube.com/vi/q5e9X9-D9kM/maxresdefault.jpg"
  },
  {
    title: "Trades – Site Progress Content",
    category: "On-Site Footage",
    youtubeId: "Y8J9_z-k9Gk",
    image: "https://img.youtube.com/vi/Y8J9_z-k9Gk/maxresdefault.jpg"
  }
];

export default function Portfolio() {
  return (
    <section className="py-24 bg-neutral-900" id="work">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-black mb-6 tracking-tight">
            Recent Work <span className="text-brand-yellow">with Trades</span>
          </h2>
          <p className="text-xl text-white/60 max-w-2xl mx-auto">
            Real results for real businesses across Scotland.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <motion.a
              key={index}
              href={`https://www.youtube.com/watch?v=${project.youtubeId}`}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              className="group relative aspect-video rounded-3xl overflow-hidden bg-neutral-800 cursor-pointer block"
            >
              <Image
                src={project.image}
                alt={project.title}
                fill
                className="object-cover transition-transform duration-700 group-hover:scale-110 opacity-70"
              />
              
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-transparent to-transparent opacity-80" />
              
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="w-16 h-16 rounded-full bg-brand-yellow flex items-center justify-center text-neutral-950 shadow-2xl scale-75 group-hover:scale-100 transition-transform duration-500">
                  <Play size={24} fill="currentColor" />
                </div>
              </div>
              
              <div className="absolute bottom-8 left-8">
                <p className="text-brand-yellow font-bold text-xs uppercase tracking-widest mb-2">
                  {project.category}
                </p>
                <h3 className="text-2xl font-black text-white">
                  {project.title}
                </h3>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
