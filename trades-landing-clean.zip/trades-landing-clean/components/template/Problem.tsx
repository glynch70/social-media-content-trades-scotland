'use client';

import { motion } from 'framer-motion';
import { AlertCircle } from 'lucide-react';

export default function Problem() {
  return (
    <section className="py-24 bg-neutral-950 relative overflow-hidden">
      {/* Background Effect */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-red-500/20 blur-[150px] rounded-full" />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="space-y-8"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-red-500/10 border border-red-500/20 rounded-full text-red-500 text-sm font-bold uppercase tracking-widest mb-4">
            <AlertCircle size={16} />
            The Reality
          </div>
          
          <h2 className="text-3xl md:text-5xl font-black tracking-tight leading-tight">
            Most Trades <span className="text-white/40">Post Randomly and Get Nothing Back</span>
          </h2>
          
          <p className="text-xl md:text-2xl text-white/70 leading-relaxed font-medium">
            No plan. No consistency. No results. <span className="text-white underline decoration-brand-yellow decoration-4 underline-offset-8">Meanwhile, competitors who show up regularly win attention and enquiries.</span>
          </p>
          
          <div className="pt-12">
            <div className="w-px h-24 bg-gradient-to-b from-brand-yellow to-transparent mx-auto" />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
