'use client';

import { motion } from 'framer-motion';
import { Calendar, Camera, Send } from 'lucide-react';

const steps = [
  {
    title: "Plan",
    description: "We map out what to film",
    icon: Calendar,
    color: "bg-blue-500"
  },
  {
    title: "Film",
    description: "We capture content on-site",
    icon: Camera,
    color: "bg-brand-yellow"
  },
  {
    title: "Edit & Deliver",
    description: "Ready-to-post content for your channels",
    icon: Send,
    color: "bg-green-500"
  }
];

export default function Process() {
  return (
    <section className="py-24 bg-neutral-900 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="text-3xl md:text-5xl font-black mb-6 tracking-tight">
            How It <span className="text-brand-yellow">Works</span>
          </h2>
          <p className="text-xl md:text-2xl text-white font-bold mb-4">
            We make content simple. You focus on the job.
          </p>
          <p className="text-xl text-white/60 max-w-2xl mx-auto">
            A simple, streamlined process designed to take the weight off your shoulders.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 relative">
          {/* Connecting Line (Desktop) */}
          <div className="hidden md:block absolute top-1/2 left-0 w-full h-px bg-white/10 -translate-y-1/2 z-0" />
          
          {steps.map((step, index) => ( index !== steps.length - 1 && (
            <div key={`line-${index}`} className="hidden md:block absolute top-1/2 left-[calc(33.33%*${index+1}-40px)] w-20 h-px bg-brand-yellow/50 z-0" />
          )))}

          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2, duration: 0.6 }}
              className="relative z-10 flex flex-col items-center text-center p-8 bg-neutral-800/50 border border-white/5 rounded-3xl backdrop-blur-sm"
            >
              <div className={`w-20 h-20 rounded-2xl flex items-center justify-center mb-8 shadow-2xl ${step.color} text-neutral-950`}>
                <step.icon size={40} strokeWidth={2.5} />
              </div>
              <h3 className="text-2xl font-black mb-4 uppercase tracking-wider">{step.title}</h3>
              <p className="text-lg text-white/70 font-medium leading-relaxed">
                {step.description}
              </p>
              
              {/* Step Number */}
              <div className="absolute -top-4 -right-4 w-10 h-10 rounded-full bg-neutral-950 border border-white/10 flex items-center justify-center text-brand-yellow font-black text-sm">
                0{index + 1}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
