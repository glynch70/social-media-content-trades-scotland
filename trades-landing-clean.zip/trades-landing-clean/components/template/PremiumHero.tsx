'use client';

import { motion } from 'framer-motion';
import { Play, ArrowRight } from 'lucide-react';
import Image from 'next/image';

interface PremiumHeroProps {
  label?: string;
  headline?: React.ReactNode;
  supportingText?: string;
  primaryCTA?: { text: string; href: string };
  secondaryCTA?: { text: string; href: string };
  videoSrc?: string;
  fallbackImage?: string;
  previewImage?: string;
}

export default function PremiumHero({
  label = "VISIBILITY & LEADS SYSTEM",
  headline = "Get More Local Work With Consistent Content for Trades in Scotland",
  supportingText = "Content that helps trades businesses stay visible and win more local work.",
  primaryCTA = { text: "Check Availability", href: "/book" },
  secondaryCTA = { text: "See Our Work", href: "#work" },
  videoSrc = "/bm-drone-hero.mp4",
  fallbackImage = "https://images.unsplash.com/photo-1541888946425-d81bb19480c5?auto=format&fit=crop&q=80",
  previewImage = "https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&q=80"
}: PremiumHeroProps) {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-neutral-950">
      {/* Background Video/Image */}
      <div className="absolute inset-0 z-0">
        <video
          autoPlay
          muted
          loop
          playsInline
          className="w-full h-full object-cover opacity-40"
          src={videoSrc}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-black/80" />
      </div>

      {/* Decorative Glows */}
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-brand-yellow/10 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-brand-yellow/5 blur-[100px] rounded-full pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-20 w-full">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* LEFT SIDE: Text Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="text-brand-yellow font-bold uppercase tracking-[0.3em] text-xs mb-6"
            >
              {label}
            </motion.p>
            
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
              className="text-[2.5rem] sm:text-[3.5rem] md:text-[4.5rem] font-black leading-[1.1] tracking-tight mb-4"
            >
              {headline}
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.35, duration: 0.6 }}
              className="text-xl md:text-2xl text-brand-yellow font-bold mb-8"
            >
              Stop relying on word of mouth and inconsistent posts.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.6 }}
              className="text-white/90 font-bold text-lg mb-8 flex flex-col gap-1"
            >
              <p>We come to you.</p>
              <p>We film it.</p>
              <p>We edit it.</p>
              <p>Your channels stay full.</p>
            </motion.div>
            
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.45, duration: 0.6 }}
              className="text-lg md:text-xl text-white/60 mb-12 max-w-lg leading-relaxed font-medium"
            >
              {supportingText}
            </motion.p>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.6 }}
              className="flex flex-wrap gap-5"
            >
              <a
                href={primaryCTA.href}
                className="px-10 py-5 bg-brand-yellow text-neutral-950 font-black uppercase tracking-widest text-sm rounded-xl hover:scale-105 hover:shadow-[0_20px_50px_rgba(221,163,30,0.3)] transition-all duration-300"
              >
                {primaryCTA.text}
              </a>
              <a
                href={secondaryCTA.href}
                className="px-10 py-5 border border-white/20 text-white font-bold uppercase tracking-widest text-sm rounded-xl hover:bg-white/5 transition-all duration-300 flex items-center gap-2"
              >
                <Play size={16} className="fill-white" />
                {secondaryCTA.text}
              </a>
            </motion.div>
          </motion.div>

          {/* RIGHT SIDE: Visual Card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="relative"
          >
            <motion.div
              animate={{ y: [0, -15, 0] }}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
              className="relative rounded-[2rem] overflow-hidden border border-white/10 shadow-2xl bg-neutral-900/40 backdrop-blur-md aspect-[4/3] md:aspect-video"
            >
              <video
                src="/media/hero-drone.mp4"
                poster="https://img.youtube.com/vi/R2j9yS5-K8o/maxresdefault.jpg"
                autoPlay
                muted
                loop
                playsInline
                className="w-full h-full object-cover opacity-80"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-brand-yellow/20 to-transparent pointer-events-none" />
              
              {/* Floating Overlay Info */}
              <div className="absolute bottom-6 left-6 right-6 p-4 bg-black/40 backdrop-blur-xl rounded-2xl border border-white/10">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-brand-yellow/20 flex items-center justify-center">
                    <Play size={16} className="text-brand-yellow fill-brand-yellow" />
                  </div>
                  <div>
                    <p className="text-white font-bold text-sm tracking-tight">Builder</p>
                    <p className="text-white/50 text-[10px] uppercase tracking-widest">Project Walkthrough</p>
                  </div>
                </div>
              </div>
            </motion.div>
            
            {/* Background Accent for Card */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-brand-yellow/20 blur-3xl rounded-full -z-10" />
            <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-white/10 blur-3xl rounded-full -z-10" />
          </motion.div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <div className="w-px h-12 bg-gradient-to-b from-brand-yellow/50 to-transparent" />
        <span className="text-[10px] uppercase tracking-[0.5em] text-white/30 rotate-180 [writing-mode:vertical-lr]">Scroll</span>
      </motion.div>
    </section>
  );
}
